﻿#include <windows.h>
#include <winhttp.h>
#include <wincrypt.h>
#include <psapi.h>
#include <tlhelp32.h>
#include <iostream>
#include <sstream>
#include <string>
#include <array>
#include <memory>
#include <vector>
#include <iomanip>
#include <map>
#include <algorithm>
#include <ctime>
#include "oxorany_include.h"

#pragma comment(lib, "winhttp.lib")
#pragma comment(lib, "crypt32.lib")
#pragma comment(lib, "psapi.lib")

const unsigned char XOR_KEY = oxorany(0xAB);
const std::string HMAC_SECRET = oxorany("0c51fb8dde8c7e944b36d179b41ccfd792ea524bf014badfb9103b98ceb263e1"); // don't change !
const std::wstring SERVER_HOST = oxorany(L"sxtpa.shop");
const std::wstring SERVER_PATH = oxorany(L"/apicheck.php");
const std::string APP_KEY = oxorany(""); // change ur app key here
const bool USE_HTTPS = true;

volatile int g_securityCheck1 = oxorany(0x12345678);
volatile int g_securityCheck2 = oxorany(0x87654321);
volatile bool g_debuggerDetected = false;
volatile int g_authState = oxorany(0);
volatile DWORD g_verifyChecksum = oxorany(0);
volatile bool g_tamperDetected = false;
std::string g_responseData = "";
std::string g_requestLicense = "";
std::string g_requestHWID = "";

bool isHTTPDebuggerRunning() {
    HANDLE hProcessSnap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (hProcessSnap == INVALID_HANDLE_VALUE) {
        return false;
    }

    PROCESSENTRY32 pe32;
    pe32.dwSize = sizeof(PROCESSENTRY32);

    if (!Process32First(hProcessSnap, &pe32)) {
        CloseHandle(hProcessSnap);
        return false;
    }

    bool found = false;
    do {
        std::string processName(pe32.szExeFile);
        if (processName == oxorany("HTTPDebuggerSvc.exe") || processName == oxorany("HTTPDebuggerUI.exe")) {
            found = true;
            break;
        }
    } while (Process32Next(hProcessSnap, &pe32));

    CloseHandle(hProcessSnap);
    return found;
}

bool checkMemoryIntegrity() {
    if (g_securityCheck1 != oxorany(0x12345678)) return false;
    if (g_securityCheck2 != oxorany(0x87654321)) return false;
    return true;
}

void antiDisassembly() {
    volatile int x = rand();
    if (x > oxorany(0x7FFFFFFF)) {
        MessageBoxA(NULL, oxorany("Error"), oxorany("Error"), MB_OK);
        ExitProcess(oxorany(1));
    }
}

DWORD calculateCRC32(BYTE* data, DWORD length) {
    DWORD crc = oxorany(0xFFFFFFFF);
    for (DWORD i = 0; i < length; i++) {
        crc ^= data[i];
        for (int j = 0; j < 8; j++) {
            crc = (crc >> 1) ^ (oxorany(0xEDB88320) & (0 - (crc & 1)));
        }
    }
    return ~crc;
}

bool verifySelfIntegrity() {
    HMODULE hModule = GetModuleHandle(NULL);
    if (!hModule) return false;

    MODULEINFO modInfo;
    if (!GetModuleInformation(GetCurrentProcess(), hModule, &modInfo, sizeof(modInfo))) {
        return false;
    }

    DWORD checksum = calculateCRC32((BYTE*)hModule, (DWORD)min((SIZE_T)modInfo.SizeOfImage, (SIZE_T)4096));

    static DWORD expectedChecksum = 0;
    if (expectedChecksum == 0) {
        expectedChecksum = checksum;
        return true;
    }

    return (checksum == expectedChecksum);
}

bool detectHooks() {
    HMODULE hKernel32 = GetModuleHandleA(oxorany("kernel32.dll"));
    if (!hKernel32) return false;

    FARPROC pIsDebuggerPresent = GetProcAddress(hKernel32, oxorany("IsDebuggerPresent"));
    if (!pIsDebuggerPresent) return false;

    BYTE* addr = (BYTE*)pIsDebuggerPresent;

    if (addr[0] == oxorany(0xE9) || (addr[0] == oxorany(0x68) && addr[5] == oxorany(0xC3)) ||
        (addr[0] == oxorany(0xFF) && addr[1] == oxorany(0x25))) {
        return true;
    }

    return false;
}

DWORD WINAPI securityMonitorThread(LPVOID param) {
    while (true) {
        Sleep(oxorany(500));

        if (isHTTPDebuggerRunning()) {
            g_debuggerDetected = true;
            g_tamperDetected = true;
            ExitProcess(oxorany(0xDEADBEEF));
        }

        if (!checkMemoryIntegrity()) {
            g_tamperDetected = true;
            ExitProcess(oxorany(0xDEADC0DE));
        }

        if (detectHooks()) {
            g_tamperDetected = true;
            ExitProcess(oxorany(0xBADC0DE));
        }

        if (g_authState == oxorany(3)) {
            if (g_verifyChecksum != oxorany(0x9ABCDEF0)) {
                g_tamperDetected = true;
                ExitProcess(oxorany(0xFAE7A));
            }
        }
    }
    return 0;
}

void startSecurityMonitoring() {
    HANDLE hThread = CreateThread(NULL, 0, securityMonitorThread, NULL, 0, NULL);
    if (hThread) {
        SetThreadPriority(hThread, THREAD_PRIORITY_HIGHEST);
    }
}

std::string execCmd(const char* cmd) {
    std::array<char, 128> buffer;
    std::string result;
    std::unique_ptr<FILE, decltype(&_pclose)> pipe(_popen(cmd, oxorany("r")), _pclose);
    if (!pipe) return oxorany("UNKNOWN");
    while (fgets(buffer.data(), buffer.size(), pipe.get()) != nullptr) {
        result += buffer.data();
    }
    return result;
}

std::string urlEncode(const std::string& value) {
    std::ostringstream escaped;
    escaped.fill('0');
    escaped << std::hex;

    for (char c : value) {
        if (isalnum((unsigned char)c) || c == '-' || c == '_' || c == '.' || c == '~') {
            escaped << c;
        }
        else {
            escaped << std::uppercase;
            escaped << '%' << std::setw(2) << int((unsigned char)c);
            escaped << std::nouppercase;
        }
    }
    return escaped.str();
}

std::string sha256(const std::string& data) {
    HCRYPTPROV hProv = 0;
    HCRYPTHASH hHash = 0;
    std::string result;

    if (CryptAcquireContext(&hProv, NULL, NULL, PROV_RSA_AES, CRYPT_VERIFYCONTEXT)) {
        if (CryptCreateHash(hProv, CALG_SHA_256, 0, 0, &hHash)) {
            if (CryptHashData(hHash, (BYTE*)data.c_str(), (DWORD)data.length(), 0)) {
                DWORD hashLen = oxorany((DWORD)32);
                BYTE hash[32];
                if (CryptGetHashParam(hHash, HP_HASHVAL, hash, &hashLen, 0)) {
                    std::ostringstream oss;
                    for (DWORD i = 0; i < hashLen; i++) {
                        oss << std::hex << std::setw(2) << std::setfill('0') << (int)hash[i];
                    }
                    result = oss.str();
                }
            }
            CryptDestroyHash(hHash);
        }
        CryptReleaseContext(hProv, 0);
    }
    return result;
}

std::string hmacSHA256(const std::string& key, const std::string& data) {
    const size_t blockSize = oxorany((size_t)64);
    const size_t hashSize = oxorany((size_t)32);

    std::string actualKey = key;
    if (actualKey.length() > blockSize) {
        actualKey = sha256(actualKey);
        std::string binKey;
        for (size_t i = 0; i < actualKey.length(); i += 2) {
            std::string byteString = actualKey.substr(i, 2);
            binKey += (char)strtol(byteString.c_str(), NULL, 16);
        }
        actualKey = binKey;
    }
    if (actualKey.length() < blockSize) {
        actualKey.append(blockSize - actualKey.length(), '\0');
    }

    std::string ipad(blockSize, oxorany(0x36));
    std::string opad(blockSize, oxorany(0x5c));

    for (size_t i = 0; i < blockSize; i++) {
        ipad[i] ^= actualKey[i];
        opad[i] ^= actualKey[i];
    }

    std::string innerHash = sha256(ipad + data);

    std::string innerBin;
    for (size_t i = 0; i < innerHash.length(); i += 2) {
        std::string byteString = innerHash.substr(i, 2);
        innerBin += (char)strtol(byteString.c_str(), NULL, 16);
    }

    return sha256(opad + innerBin);
}

std::string getHWID() {
    std::string uuid = execCmd(oxorany("wmic path win32_computersystemproduct get uuid"));
    std::string cpu = execCmd(oxorany("wmic cpu get processorid"));
    std::string disk = execCmd(oxorany("wmic diskdrive get serialnumber"));

    std::istringstream iss(uuid);
    std::string line, hwid;
    std::getline(iss, line);
    std::getline(iss, line);
    if (!line.empty()) {
        line.erase(0, line.find_first_not_of(" \t\r\n"));
        line.erase(line.find_last_not_of(" \t\r\n") + 1);
        hwid = line;
    }

    return hwid;
}

std::string httpGet(const std::wstring& host, const std::wstring& path) {
    std::string result;
    HINTERNET hSession = WinHttpOpen(oxorany(L"AuthClient/1.0"), WINHTTP_ACCESS_TYPE_DEFAULT_PROXY,
        WINHTTP_NO_PROXY_NAME, WINHTTP_NO_PROXY_BYPASS, 0);
    if (!hSession) return oxorany("NO_SESSION");
    HINTERNET hConnect = WinHttpConnect(hSession, host.c_str(), INTERNET_DEFAULT_HTTPS_PORT, 0);
    if (!hConnect) { WinHttpCloseHandle(hSession); return oxorany("NO_CONNECT"); }
    HINTERNET hRequest = WinHttpOpenRequest(hConnect, oxorany(L"GET"), path.c_str(),
        NULL, WINHTTP_NO_REFERER,
        WINHTTP_DEFAULT_ACCEPT_TYPES,
        WINHTTP_FLAG_SECURE);
    if (!hRequest) { WinHttpCloseHandle(hConnect); WinHttpCloseHandle(hSession); return oxorany("NO_REQ"); }
    BOOL bResults = WinHttpSendRequest(hRequest,
        WINHTTP_NO_ADDITIONAL_HEADERS, 0,
        WINHTTP_NO_REQUEST_DATA, 0, 0, 0);
    if (bResults) bResults = WinHttpReceiveResponse(hRequest, NULL);
    if (bResults) {
        DWORD dwSize = 0;
        do {
            WinHttpQueryDataAvailable(hRequest, &dwSize);
            if (!dwSize) break;
            std::vector<char> buffer(dwSize + 1);
            DWORD dwDownloaded = 0;
            WinHttpReadData(hRequest, buffer.data(), dwSize, &dwDownloaded);
            buffer[dwDownloaded] = 0;
            result += buffer.data();
        } while (dwSize > 0);
    }
    WinHttpCloseHandle(hRequest);
    WinHttpCloseHandle(hConnect);
    WinHttpCloseHandle(hSession);
    return result;
}

std::string httpPost(const std::wstring& host, const std::wstring& path, const std::string& data, bool useHttps = true) {
    volatile DWORD preRequestChecksum = calculateCRC32((BYTE*)data.c_str(), (DWORD)data.length());

    std::string result;
    HINTERNET hSession = WinHttpOpen(oxorany(L"OxyAuth/2.0"), WINHTTP_ACCESS_TYPE_DEFAULT_PROXY,
        WINHTTP_NO_PROXY_NAME, WINHTTP_NO_PROXY_BYPASS, 0);
    if (!hSession) return oxorany("ERROR:NO_SESSION");

    if (isHTTPDebuggerRunning()) {
        WinHttpCloseHandle(hSession);
        ExitProcess(0xDEADBEEF);
        return oxorany("ERROR:DEBUGGER");
    }

    INTERNET_PORT port = useHttps ? INTERNET_DEFAULT_HTTPS_PORT : INTERNET_DEFAULT_HTTP_PORT;
    HINTERNET hConnect = WinHttpConnect(hSession, host.c_str(), port, 0);
    if (!hConnect) {
        WinHttpCloseHandle(hSession);
        return oxorany("ERROR:NO_CONNECT");
    }

    DWORD flags = useHttps ? WINHTTP_FLAG_SECURE : 0;
    HINTERNET hRequest = WinHttpOpenRequest(hConnect, oxorany(L"POST"), path.c_str(),
        NULL, WINHTTP_NO_REFERER,
        WINHTTP_DEFAULT_ACCEPT_TYPES, flags);
    if (!hRequest) {
        WinHttpCloseHandle(hConnect);
        WinHttpCloseHandle(hSession);
        return oxorany("ERROR:NO_REQUEST");
    }

    if (useHttps) {
        DWORD dwFlags = SECURITY_FLAG_IGNORE_UNKNOWN_CA |
            SECURITY_FLAG_IGNORE_CERT_DATE_INVALID |
            SECURITY_FLAG_IGNORE_CERT_CN_INVALID |
            SECURITY_FLAG_IGNORE_CERT_WRONG_USAGE;
        WinHttpSetOption(hRequest, WINHTTP_OPTION_SECURITY_FLAGS, &dwFlags, sizeof(dwFlags));
    }

    std::wstring headers = oxorany(L"Content-Type: application/x-www-form-urlencoded\r\n");
    BOOL bResults = WinHttpSendRequest(hRequest,
        headers.c_str(), (DWORD)-1L,
        (LPVOID)data.c_str(), (DWORD)data.length(),
        (DWORD)data.length(), 0);

    if (bResults) bResults = WinHttpReceiveResponse(hRequest, NULL);

    if (bResults) {
        if (isHTTPDebuggerRunning() || !checkMemoryIntegrity()) {
            WinHttpCloseHandle(hRequest);
            WinHttpCloseHandle(hConnect);
            WinHttpCloseHandle(hSession);
            ExitProcess(oxorany(0x0E77A3E));
            return oxorany("ERROR:TAMPERED");
        }

        DWORD dwSize = 0;
        do {
            WinHttpQueryDataAvailable(hRequest, &dwSize);
            if (!dwSize) break;
            std::vector<char> buffer(dwSize + 1);
            DWORD dwDownloaded = 0;
            WinHttpReadData(hRequest, buffer.data(), dwSize, &dwDownloaded);
            buffer[dwDownloaded] = 0;
            result += buffer.data();
        } while (dwSize > 0);
    }
    else {
        result = oxorany("ERROR:NO_RESPONSE");
    }

    if (result.length() > 0 && result.find("VALID|") == 0) {
        if (result.find('|') == std::string::npos ||
            std::count(result.begin(), result.end(), '|') != 2) {
            result = oxorany("ERROR:INVALID_FORMAT");
        }
    }

    WinHttpCloseHandle(hRequest);
    WinHttpCloseHandle(hConnect);
    WinHttpCloseHandle(hSession);

    volatile DWORD postRequestChecksum = calculateCRC32((BYTE*)data.c_str(), (DWORD)data.length());
    if (preRequestChecksum != postRequestChecksum) {
        ExitProcess(oxorany(0xEE07A3E));
        return oxorany("ERROR:REQUEST_TAMPERED");
    }

    return result;
}

std::string getErrorMessage(const std::string& code) {
    static std::map<std::string, std::string> errors = {
        {oxorany("VALID"), oxorany("Authentication successful!")},
        {oxorany("INVALID_REQUEST"), oxorany("Malformed request or IP not detected")},
        {oxorany("ACCESS_DENIED"), oxorany("Your IP address is blacklisted")},
        {oxorany("TOO_MANY_ATTEMPTS"), oxorany("Too many failed attempts. Please try again later")},
        {oxorany("MISSING_PARAMS"), oxorany("Required parameters missing")},
        {oxorany("INVALID_FORMAT"), oxorany("Invalid input format")},
        {oxorany("INVALID_TIMESTAMP"), oxorany("Request timestamp invalid or expired")},
        {oxorany("INVALID_SIGNATURE"), oxorany("Security signature verification failed")},
        {oxorany("RATE_LIMIT_EXCEEDED"), oxorany("Too many requests. Please wait and try again")},
        {oxorany("INVALID_APP"), oxorany("Application key not recognized")},
        {oxorany("INVALID_LICENSE"), oxorany("License key is invalid")},
        {oxorany("LICENSE_BANNED"), oxorany("This license has been banned")},
        {oxorany("EXPIRED"), oxorany("License has expired")},
        {oxorany("HWID_MISMATCH"), oxorany("Hardware ID mismatch. License bound to another device")},
        {oxorany("SYSTEM_ERROR"), oxorany("Server error. Please contact support")},
        {oxorany("ERROR:NO_SESSION"), oxorany("Failed to create HTTP session")},
        {oxorany("ERROR:NO_CONNECT"), oxorany("Failed to connect to server")},
        {oxorany("ERROR:NO_REQUEST"), oxorany("Failed to create HTTP request")},
        {oxorany("ERROR:NO_RESPONSE"), oxorany("Failed to receive server response")},
        {oxorany("TAMPERED_RESPONSE"), oxorany("Server response has been tampered with!")}
    };

    auto it = errors.find(code);
    return (it != errors.end()) ? it->second : oxorany("Unknown error: ") + code;
}

std::vector<std::string> splitString(const std::string& str, char delimiter) {
    std::vector<std::string> tokens;
    std::string token;
    std::istringstream tokenStream(str);
    while (std::getline(tokenStream, token, delimiter)) {
        tokens.push_back(token);
    }
    return tokens;
}

std::string base64_decode(const std::string& encoded) {
    const std::string base64_chars =
        "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
        "abcdefghijklmnopqrstuvwxyz"
        "0123456789+/";

    std::string decoded;
    std::vector<int> T(256, -1);
    for (int i = 0; i < 64; i++) T[base64_chars[i]] = i;

    int val = 0, valb = -8;
    for (unsigned char c : encoded) {
        if (T[(int)c] == -1) break;
        val = (val << 6) + T[c];
        valb += 6;
        if (valb >= 0) {
            decoded.push_back(char((val >> valb) & 0xFF));
            valb -= 8;
        }
    }
    return decoded;
}

bool verifyServerResponse(const std::string& response) {
    g_authState = oxorany(1);

    antiDisassembly();
    if (g_debuggerDetected || g_tamperDetected) return false;

    std::vector<std::string> parts = splitString(response, oxorany('|'));

    if (parts.size() != oxorany(3)) {
        g_authState = oxorany(2);
        return false;
    }

    if (!checkMemoryIntegrity()) {
        ExitProcess(0xDEADC0DE);
        return false;
    }

    std::string status = parts[oxorany(0)];
    std::string encodedData = parts[oxorany(1)];
    std::string signature = parts[oxorany(2)];

    volatile int statusCheck1 = (status == oxorany("VALID")) ? oxorany(0x11) : oxorany(0x00);
    volatile int statusCheck2 = (status.length() == oxorany(5)) ? oxorany(0x22) : oxorany(0x00);
    volatile int statusCheck3 = (status[oxorany(0)] == oxorany('V')) ? oxorany(0x44) : oxorany(0x00);
    volatile int statusCheck4 = (status[oxorany(4)] == oxorany('D')) ? oxorany(0x88) : oxorany(0x00);

    if ((statusCheck1 | statusCheck2 | statusCheck3 | statusCheck4) != oxorany(0xFF)) {
        g_authState = oxorany(2);
        return false;
    }

    std::string jsonData = base64_decode(encodedData);

    if (isHTTPDebuggerRunning()) {
        g_debuggerDetected = true;
        ExitProcess(oxorany(0xDEADBEEF));
        return false;
    }

    std::string expectedSignature = hmacSHA256(HMAC_SECRET, jsonData);

    if (expectedSignature.length() != signature.length()) {
        g_authState = oxorany(2);
        return false;
    }

    antiDisassembly();

    int verifyRound1 = 0;
    int verifyRound2 = 0;
    int verifyRound3 = 0;

    for (size_t i = 0; i < expectedSignature.length(); i++) {
        verifyRound1 |= expectedSignature[i] ^ signature[i];
        if (i % oxorany(3) == oxorany(0)) verifyRound2 |= expectedSignature[i] ^ signature[i];
        if (i % oxorany(2) == oxorany(0)) verifyRound3 |= expectedSignature[i] ^ signature[i];
    }

    if (verifyRound1 != oxorany(0) || verifyRound2 != oxorany(0) || verifyRound3 != oxorany(0)) {
        g_authState = oxorany(2);
        return false;
    }

    if (!verifySelfIntegrity()) {
        ExitProcess(oxorany(0xBADF00D));
        return false;
    }

    size_t timestampPos = jsonData.find(oxorany("\"timestamp\":"));
    if (timestampPos != std::string::npos) {
        size_t numStart = timestampPos + oxorany(12);
        size_t numEnd = jsonData.find_first_of(oxorany(",}"), numStart);
        if (numEnd != std::string::npos) {
            std::string timestampStr = jsonData.substr(numStart, numEnd - numStart);
            long long serverTime = std::stoll(timestampStr);
            long long currentTime = (long long)time(0);

            if (abs(currentTime - serverTime) > oxorany(30)) {
                g_authState = oxorany(2);
                return false;
            }
        }
    }

    g_responseData = jsonData;

    if (detectHooks()) {
        ExitProcess(oxorany(0xBADC0DE));
        return false;
    }

    g_verifyChecksum = oxorany(0x9ABCDEF0);

    g_authState = oxorany(3);

    return true;
}

int main() {
    if (isHTTPDebuggerRunning()) {
        ExitProcess(oxorany(0));
        return oxorany(1);
    }

    startSecurityMonitoring();

    if (!verifySelfIntegrity()) {
        std::cout << oxorany("Application integrity check failed.\n");
        system(oxorany("pause"));
        return oxorany(1);
    }

    if (detectHooks()) {
        ExitProcess(oxorany(0));
        return oxorany(1);
    }

    std::cout << oxorany("=================================\n");
    std::cout << oxorany("  OxyAuth Secure License System  \n");
    std::cout << oxorany("=================================\n\n");

    std::string license;
    std::cout << oxorany("Enter your license key: ");
    std::getline(std::cin, license);

    if (isHTTPDebuggerRunning() || !checkMemoryIntegrity()) {
        ExitProcess(oxorany(0));
        return oxorany(1);
    }

    if (license.empty()) {
        std::cout << oxorany("[-] License key cannot be empty!\n");
        system(oxorany("pause"));
        return oxorany(1);
    }

    std::cout << oxorany("\n[*] Generating hardware fingerprint...\n");

    antiDisassembly();
    if (isHTTPDebuggerRunning()) {
        ExitProcess(oxorany(0));
        return oxorany(1);
    }

    std::string hwid = getHWID();
    if (hwid == oxorany("UNKNOWN_HWID")) {
        std::cout << oxorany("[-] Warning: Could not generate hardware ID\n");
    }

    g_requestLicense = license;
    g_requestHWID = hwid;

    if (!checkMemoryIntegrity()) {
        ExitProcess(oxorany(0));
        return oxorany(1);
    }

    std::cout << oxorany("[*] Preparing authentication request...\n");

    std::string timestamp = std::to_string((long long)time(0));

    std::map<std::string, std::string> params;
    params["appkey"] = APP_KEY;
    params["license"] = license;
    params["hwid"] = hwid;
    params["timestamp"] = timestamp;

    std::ostringstream hmacData;
    bool first = true;
    for (const auto& pair : params) {
        if (!first) hmacData << "&";
        hmacData << pair.first << "=" << urlEncode(pair.second);
        first = false;
    }

    std::string signature = hmacSHA256(HMAC_SECRET, hmacData.str());

    std::ostringstream body;
    body << "appkey=" << urlEncode(APP_KEY)
        << "&license=" << urlEncode(license)
        << "&hwid=" << urlEncode(hwid)
        << "&timestamp=" << timestamp
        << "&signature=" << signature;

    std::cout << oxorany("[*] Authenticating with server...\n\n");

    if (isHTTPDebuggerRunning() || g_debuggerDetected) {
        ExitProcess(oxorany(0));
        return oxorany(1);
    }

    antiDisassembly();
    if (!checkMemoryIntegrity() || !verifySelfIntegrity()) {
        ExitProcess(oxorany(0));
        return oxorany(1);
    }

    std::string result = httpPost(SERVER_HOST, SERVER_PATH, body.str(), USE_HTTPS);

    bool isAuthentic = verifyServerResponse(result);

    volatile bool check1 = (g_authState == oxorany(3));
    volatile bool check2 = (g_verifyChecksum == oxorany(0x9ABCDEF0));
    volatile bool check3 = isAuthentic;
    volatile bool check4 = !g_tamperDetected;
    volatile bool check5 = !g_debuggerDetected;
    volatile bool check6 = checkMemoryIntegrity();

    volatile int finalCheck = 0;
    if (check1) finalCheck |= 0x01;
    if (check2) finalCheck |= 0x02;
    if (check3) finalCheck |= 0x04;
    if (check4) finalCheck |= 0x08;
    if (check5) finalCheck |= 0x10;
    if (check6) finalCheck |= 0x20;

    bool allChecksPassed = (finalCheck == oxorany(0x3F));

    bool doubleCheck = (result.find(oxorany("VALID|")) == 0) && isAuthentic && (g_authState == oxorany(3));

    if (!allChecksPassed || !doubleCheck) {
        isAuthentic = false;
        g_authState = oxorany(2);
    }

    if (isAuthentic && allChecksPassed && doubleCheck && g_authState == oxorany(3) && !g_tamperDetected) {
        bool licenseMatch = (g_responseData.find(oxorany("\"") + g_requestLicense + oxorany("\"")) != std::string::npos);
        bool hwidMatch = (g_responseData.find(oxorany("\"") + g_requestHWID + oxorany("\"")) != std::string::npos);

        if (!licenseMatch || !hwidMatch) {
            std::cout << oxorany("====================================") << std::endl;
            std::cout << oxorany("[-] AUTHENTICATION FAILED\n");
            std::cout << oxorany("====================================") << std::endl;
            std::cout << oxorany("[!] REPLAY ATTACK DETECTED!\n\n");
            std::cout << oxorany("The server response does not match your request.\n");
            std::cout << oxorany("Someone may be replaying a captured response.\n\n");
            std::cout << oxorany("Error: ") << getErrorMessage(oxorany("TAMPERED_RESPONSE")) << oxorany("\n\n");
            std::cout << oxorany("If you believe this is an error, please contact support.\n");
            system(oxorany("pause"));
            return oxorany(1);
        }

        std::cout << oxorany("====================================") << std::endl;
        std::cout << oxorany("[+] ") << getErrorMessage(oxorany("VALID")) << oxorany("\n");
        std::cout << oxorany("====================================") << std::endl;
        std::cout << oxorany("\n[+] Response signature verified - server is authentic\n");
        std::cout << oxorany("[+] Anti-replay protection: ACTIVE\n");
        std::cout << oxorany("[+] Anti-tamper protection: ACTIVE\n\n");
        std::cout << oxorany("Your application will now start...\n"); // Place your application logic here
        if (g_authState != oxorany(3) || g_verifyChecksum != oxorany(0x9ABCDEF0)) {
            std::cout << oxorany("\n[!] Final verification failed!\n");
            system(oxorany("pause"));
            return oxorany(1);
        }

        Sleep(oxorany(100));
        if (g_tamperDetected || g_debuggerDetected) {
            ExitProcess(oxorany(0));
            return oxorany(1);
        }
    }
    else {
        std::cout << oxorany("====================================\n");
        std::cout << oxorany("[-] AUTHENTICATION FAILED\n");
        std::cout << oxorany("====================================\n");

        if (result.find(oxorany('|')) == std::string::npos) {
            if (result == oxorany("VALID") || result.find(oxorany("VALID")) == oxorany(0)) {
                std::cout << oxorany("[!] CRITICAL SECURITY WARNING [!]\n");
                std::cout << oxorany("TAMPERING DETECTED!\n\n");
                std::cout << oxorany("Someone attempted to bypass authentication by\n");
                std::cout << oxorany("modifying the server response to: \"") << result << oxorany("\"\n\n");
                std::cout << oxorany("This authentication system requires cryptographic\n");
                std::cout << oxorany("signatures that cannot be forged. The tampering\n");
                std::cout << oxorany("attempt has been blocked.\n\n");
                std::cout << oxorany("Error: ") << getErrorMessage(oxorany("TAMPERED_RESPONSE")) << oxorany("\n\n");
            }
            else {
                std::cout << oxorany("Server Response: ") << getErrorMessage(result) << oxorany("\n");
                std::cout << oxorany("Error Code: ") << result << oxorany("\n\n");
            }
        }
        else {
            std::cout << oxorany("[!] CRITICAL SECURITY WARNING [!]\n");
            std::cout << oxorany("Response signature verification FAILED!\n");
            std::cout << oxorany("Possible causes:\n");
            std::cout << oxorany("  - Network traffic is being intercepted/modified\n");
            std::cout << oxorany("  - Man-in-the-middle attack detected\n");
            std::cout << oxorany("  - tampering detected\n");
            std::cout << oxorany("  - HMAC_SECRET mismatch between client and server\n\n");
            std::cout << oxorany("Error: ") << getErrorMessage(oxorany("TAMPERED_RESPONSE")) << oxorany("\n\n");
        }

        std::cout << oxorany("If you believe this is an error, please contact support.\n");
    }

    std::cout << oxorany("\n");
    system(oxorany("pause"));

    if (g_authState != oxorany(3) || g_tamperDetected) {
        return oxorany(1);
    }

    return (isAuthentic && allChecksPassed && doubleCheck && g_authState == oxorany(3)) ? oxorany(0) : oxorany(1);
}