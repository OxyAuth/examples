#include <windows.h>
#include <winhttp.h>
#include <iostream>
#include <sstream>
#include <string>
#include <array>
#include <memory>
#include <vector>

#pragma comment(lib, "winhttp.lib")

std::string execCmd(const char* cmd) {
    std::array<char, 128> buffer;
    std::string result;
    std::unique_ptr<FILE, decltype(&_pclose)> pipe(_popen(cmd, "r"), _pclose);
    if (!pipe) return "UNKNOWN";
    while (fgets(buffer.data(), buffer.size(), pipe.get()) != nullptr) {
        result += buffer.data();
    }
    return result;
}

std::string getHWID() {
    std::string output = execCmd("wmic path win32_computersystemproduct get uuid");
    std::istringstream iss(output);
    std::string line;
    std::getline(iss, line);
    std::getline(iss, line);
    if (!line.empty()) {
        line.erase(0, line.find_first_not_of(" \t\r\n"));
        line.erase(line.find_last_not_of(" \t\r\n") + 1);
        return line;
    }
    return "UNKNOWN_HWID";
}

std::string httpGet(const std::wstring& host, const std::wstring& path) {
    std::string result;
    HINTERNET hSession = WinHttpOpen(L"AuthClient/1.0", WINHTTP_ACCESS_TYPE_DEFAULT_PROXY,
        WINHTTP_NO_PROXY_NAME, WINHTTP_NO_PROXY_BYPASS, 0);
    if (!hSession) return "NO_SESSION";
    HINTERNET hConnect = WinHttpConnect(hSession, host.c_str(), INTERNET_DEFAULT_HTTPS_PORT, 0);
    if (!hConnect) { WinHttpCloseHandle(hSession); return "NO_CONNECT"; }
    HINTERNET hRequest = WinHttpOpenRequest(hConnect, L"GET", path.c_str(),
        NULL, WINHTTP_NO_REFERER,
        WINHTTP_DEFAULT_ACCEPT_TYPES,
        WINHTTP_FLAG_SECURE);
    if (!hRequest) { WinHttpCloseHandle(hConnect); WinHttpCloseHandle(hSession); return "NO_REQ"; }
    BOOL bResults = WinHttpSendRequest(hRequest,
        WINHTTP_NO_ADDITIONAL_HEADERS, 0,
        WINHTTP_NO_REQUEST_DATA, 0, 0, 0);
    if (bResults) bResults = WinHttpReceiveResponse(hRequest, NULL);
    if (bResults) {
        DWORD dwSize = 0;
        do {
            WinHttpQueryDataAvailable(hRequest, &dwSize);
            if (!dwSize) break;
            std::vector<char> buffer(dwSize + 1);
            DWORD dwDownloaded = 0;
            WinHttpReadData(hRequest, buffer.data(), dwSize, &dwDownloaded);
            buffer[dwDownloaded] = 0;
            result += buffer.data();
        } while (dwSize > 0);
    }
    WinHttpCloseHandle(hRequest);
    WinHttpCloseHandle(hConnect);
    WinHttpCloseHandle(hSession);
    return result;
}

std::string httpPost(const std::wstring& host, const std::wstring& path, const std::string& data) {
    std::string result;
    HINTERNET hSession = WinHttpOpen(L"AuthClient/1.0", WINHTTP_ACCESS_TYPE_DEFAULT_PROXY,
        WINHTTP_NO_PROXY_NAME, WINHTTP_NO_PROXY_BYPASS, 0);
    if (!hSession) return "NO_SESSION";
    HINTERNET hConnect = WinHttpConnect(hSession, host.c_str(), INTERNET_DEFAULT_HTTP_PORT, 0);
    if (!hConnect) { WinHttpCloseHandle(hSession); return "NO_CONNECT"; }
    HINTERNET hRequest = WinHttpOpenRequest(hConnect, L"POST", path.c_str(),
        NULL, WINHTTP_NO_REFERER,
        WINHTTP_DEFAULT_ACCEPT_TYPES, 0);
    if (!hRequest) { WinHttpCloseHandle(hConnect); WinHttpCloseHandle(hSession); return "NO_REQ"; }

    std::wstring headers = L"Content-Type: application/x-www-form-urlencoded\r\n";
    BOOL bResults = WinHttpSendRequest(hRequest,
        headers.c_str(), (DWORD)-1L,
        (LPVOID)data.c_str(), data.length(),
        data.length(), 0);
    if (bResults) bResults = WinHttpReceiveResponse(hRequest, NULL);
    if (bResults) {
        DWORD dwSize = 0;
        do {
            WinHttpQueryDataAvailable(hRequest, &dwSize);
            if (!dwSize) break;
            std::vector<char> buffer(dwSize + 1);
            DWORD dwDownloaded = 0;
            WinHttpReadData(hRequest, buffer.data(), dwSize, &dwDownloaded);
            buffer[dwDownloaded] = 0;
            result += buffer.data();
        } while (dwSize > 0);
    }
    WinHttpCloseHandle(hRequest);
    WinHttpCloseHandle(hConnect);
    WinHttpCloseHandle(hSession);
    return result;
}

int main() {
    std::string license;
    std::cout << "Enter your license key: ";
    std::getline(std::cin, license);

    std::string hwid = getHWID();
    std::string publicIp = httpGet(L"api.ipify.org", L"/");

	std::string appkey = ""; // replace with your actual appkey

    std::ostringstream body;
    body << "appkey=" << appkey
        << "&license=" << license
        << "&hwid=" << hwid
        << "&ip_addr=" << publicIp;

    std::string result = httpPost(L"oxyluaprrttct.mygamesonline.org", L"/apicheck.php", body.str());

    if (result == "VALID") {
        std::cout << "[+] License valid!\n";
    }
    else {
        std::cout << "[-] Auth failed: " << result << "\n";
    }
    system("pause");
    return 0;
}
