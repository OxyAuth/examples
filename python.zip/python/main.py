import os
import sys
import time
import hmac
import hashlib
import base64
import json
import platform
import subprocess
import requests
from urllib.parse import urlencode, quote
from typing import Optional, Dict, Tuple

HMAC_SECRET = "0c51fb8dde8c7e944b36d179b41ccfd792ea524bf014badfb9103b98ceb263e1"
SERVER_HOST = "sxtpa.shop"
SERVER_PATH = "/apicheck.php"
APP_KEY = ""  # Change your app key here
USE_HTTPS = False

g_request_license = ""
g_request_hwid = ""
g_response_data = ""

def is_http_debugger_running() -> bool:
    try:
        if platform.system() == "Windows":
            output = subprocess.check_output(
                ["tasklist"], 
                universal_newlines=True, 
                stderr=subprocess.DEVNULL
            )
            debuggers = ["HTTPDebuggerSvc.exe", "HTTPDebuggerUI.exe", "Fiddler.exe", "Charles.exe"]
            return any(debugger.lower() in output.lower() for debugger in debuggers)
        else:
            output = subprocess.check_output(
                ["ps", "aux"], 
                universal_newlines=True,
                stderr=subprocess.DEVNULL
            )
            debuggers = ["mitmproxy", "charles", "fiddler"]
            return any(debugger.lower() in output.lower() for debugger in debuggers)
    except:
        return False


def get_hwid() -> str:
    try:
        if platform.system() == "Windows":
            output = subprocess.check_output(
                ["wmic", "path", "win32_computersystemproduct", "get", "uuid"],
                universal_newlines=True,
                stderr=subprocess.DEVNULL
            ).strip()
            lines = [line.strip() for line in output.split('\n') if line.strip()]
            if len(lines) > 1:
                return lines[1]
        elif platform.system() == "Linux":
            try:
                with open("/etc/machine-id", "r") as f:
                    return f.read().strip()
            except:
                pass
        elif platform.system() == "Darwin":
            output = subprocess.check_output(
                ["ioreg", "-rd1", "-c", "IOPlatformExpertDevice"],
                universal_newlines=True,
                stderr=subprocess.DEVNULL
            )
            for line in output.split('\n'):
                if "IOPlatformUUID" in line:
                    return line.split('"')[3]
        
        return "UNKNOWN_HWID"
    except:
        return "UNKNOWN_HWID"


def sha256_hash(data: str) -> str:
    return hashlib.sha256(data.encode()).hexdigest()


def hmac_sha256(key: str, data: str) -> str:
    return hmac.new(
        key.encode(),
        data.encode(),
        hashlib.sha256
    ).hexdigest()


def verify_server_response(response: str) -> Tuple[bool, str]:
    global g_response_data
    
    try:
        parts = response.split('|')
        if len(parts) != 3:
            return False, ""
        
        status, encoded_data, signature = parts

        if status != "VALID":
            return False, ""

        json_bytes = base64.b64decode(encoded_data)
        json_data = json_bytes.decode('utf-8')
        g_response_data = json_data

        expected_signature = hmac_sha256(HMAC_SECRET, json_data)
        if expected_signature.lower() != signature.lower():
            return False, ""

        data = json.loads(json_data)
        server_time = data.get('timestamp', 0)
        current_time = int(time.time())
        if abs(current_time - server_time) > 30:
            return False, ""
        
        return True, json_data
        
    except Exception as e:
        return False, ""


def get_error_message(code: str) -> str:
    errors = {
        "VALID": "Authentication successful!",
        "INVALID_REQUEST": "Malformed request or IP not detected",
        "ACCESS_DENIED": "Your IP address is blacklisted",
        "TOO_MANY_ATTEMPTS": "Too many failed attempts. Please try again later",
        "MISSING_PARAMS": "Required parameters missing",
        "INVALID_FORMAT": "Invalid input format",
        "INVALID_TIMESTAMP": "Request timestamp invalid or expired",
        "INVALID_SIGNATURE": "Security signature verification failed",
        "RATE_LIMIT_EXCEEDED": "Too many requests. Please wait and try again",
        "INVALID_APP": "Application key not recognized",
        "INVALID_LICENSE": "License key is invalid",
        "LICENSE_BANNED": "This license has been banned",
        "EXPIRED": "License has expired",
        "HWID_MISMATCH": "Hardware ID mismatch. License bound to another device",
        "SYSTEM_ERROR": "Server error. Please contact support",
        "TAMPERED_RESPONSE": "Server response has been tampered with!"
    }
    return errors.get(code, f"Unknown error: {code}")

def authenticate(license_key: str) -> Dict[str, any]:
    global g_request_license, g_request_hwid
    
    result = {
        'success': False,
        'message': '',
        'error_code': '',
        'is_replay_attack': False,
        'is_tampered': False
    }
    
    try:
        if is_http_debugger_running():
            result['message'] = "HTTP Debugger detected! Please close all debugging tools."
            result['error_code'] = "DEBUGGER_DETECTED"
            result['is_tampered'] = True
            return result

        if not license_key or not license_key.strip():
            result['message'] = "License key cannot be empty"
            result['error_code'] = "EMPTY_LICENSE"
            return result

        hwid = get_hwid()
        if hwid == "UNKNOWN_HWID":
            result['message'] = "Could not generate hardware ID"
            result['error_code'] = "HWID_ERROR"
            return result

        g_request_license = license_key
        g_request_hwid = hwid

        timestamp = str(int(time.time()))
        
        request_params = {
            'appkey': APP_KEY,
            'hwid': hwid,
            'license': license_key,
            'timestamp': timestamp
        }

        sorted_params = sorted(request_params.items())
        hmac_data = '&'.join([f"{k}={quote(str(v), safe='')}" for k, v in sorted_params])
        signature = hmac_sha256(HMAC_SECRET, hmac_data)

        post_data = {
            'appkey': APP_KEY,
            'license': license_key,
            'hwid': hwid,
            'timestamp': timestamp,
            'signature': signature
        }

        protocol = "https" if USE_HTTPS else "http"
        url = f"{protocol}://{SERVER_HOST}{SERVER_PATH}"
        
        response = requests.post(
            url,
            data=post_data,
            timeout=10,
            headers={'User-Agent': 'OxyAuth-Python/2.0'}
        )
        
        response_text = response.text.strip()

        if '|' not in response_text:
            if response_text == "VALID" or response_text.startswith("VALID"):
                result['message'] = "tampering detected! Response was modified."
                result['error_code'] = "TAMPERED_RESPONSE"
                result['is_tampered'] = True
                return result
            
            result['message'] = get_error_message(response_text)
            result['error_code'] = response_text
            return result

        is_valid, json_data = verify_server_response(response_text)
        if not is_valid:
            result['message'] = "Response signature verification failed! Possible tampering detected."
            result['error_code'] = "SIGNATURE_MISMATCH"
            result['is_tampered'] = True
            return result

        if f'"{g_request_license}"' not in g_response_data or f'"{g_request_hwid}"' not in g_response_data:
            result['message'] = "Replay attack detected! Response does not match request."
            result['error_code'] = "REPLAY_ATTACK"
            result['is_replay_attack'] = True
            return result
        
        # Success!
        result['success'] = True
        result['message'] = "Authentication successful!"
        result['error_code'] = "VALID"
        return result
        
    except requests.exceptions.RequestException as e:
        result['message'] = f"Network error: {str(e)}"
        result['error_code'] = "NETWORK_ERROR"
        return result
    except Exception as e:
        result['message'] = f"Unexpected error: {str(e)}"
        result['error_code'] = "UNKNOWN_ERROR"
        return result

def main():
    if is_http_debugger_running():
        print("[-] HTTP Debugger detected! Exiting...")
        sys.exit(1)
    
    print("=" * 50)
    print("  OxyAuth Secure License System - Python")
    print("=" * 50)
    print()

    license_key = input("Enter your license key: ").strip()
    
    if not license_key:
        print("[-] License key cannot be empty!")
        input("\nPress Enter to exit...")
        return
    
    print("\n[*] Generating hardware fingerprint...")
    print("[*] Preparing authentication request...")
    print("[*] Authenticating with server...\n")

    result = authenticate(license_key)

    if result['success']:
        print("=" * 50)
        print("[+] AUTHENTICATION SUCCESS")
        print("=" * 50)
        print("\n[+] Response signature verified - server is authentic")
        print("[+] Anti-replay protection: ACTIVE")
        print("[+] Anti-tamper protection: ACTIVE\n")
        print("Your application will now start...")
        # place your application logic here
    else:
        print("=" * 50)
        print("[-] AUTHENTICATION FAILED")
        print("=" * 50)
        
        if result['is_tampered']:
            print("\n[!] CRITICAL SECURITY WARNING [!]")
            print("TAMPERING DETECTED!\n")
            print("Someone attempted to bypass authentication by")
            print(f"modifying the server response.\n")
            print("This authentication system requires cryptographic")
            print("signatures that cannot be forged. The tampering")
            print("attempt has been blocked.\n")
        elif result['is_replay_attack']:
            print("\n[!] REPLAY ATTACK DETECTED!\n")
            print("The server response does not match your request.")
            print("Someone may be replaying a captured response.\n")
        else:
            print(f"\nServer Response: {result['message']}")
            print(f"Error Code: {result['error_code']}\n")
        
        print("If you believe this is an error, please contact support.")
    
    print()
    input("Press Enter to exit...")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\n[-] Interrupted by user")
        sys.exit(1)
    except Exception as e:
        print(f"\n[-] Fatal error: {e}")
        sys.exit(1)
