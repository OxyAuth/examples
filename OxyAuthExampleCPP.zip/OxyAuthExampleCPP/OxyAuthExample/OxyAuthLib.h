#pragma once
#include <string>
#include <vector>

namespace OxyAuth {

// Auth result structure
struct AuthResult {
    bool success;
    std::string errorMessage;
    std::string responseData;
};

// Auth parameters
struct AuthParams {
    std::string license;
    std::string username;
    std::string password;
};

// Initialize security monitoring (call once at startup)
void InitSecurity();

// Perform authentication (blocking call)
AuthResult Authenticate(const AuthParams& params);

// Utility: get HWID string
std::string GetHWID();

// Utility: generate random nonce
std::string GenerateNonce(size_t len = 16);

} // namespace OxyAuth
