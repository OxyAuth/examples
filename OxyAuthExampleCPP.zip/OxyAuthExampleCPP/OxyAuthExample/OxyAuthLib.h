#pragma once
#include <string>
#include <vector>

namespace OxyAuth {

struct AuthResult {
    bool success;
    std::string errorMessage;
    std::string responseData;
};

struct AuthParams {
    std::string appKey;
    std::string license;
    std::string username;
    std::string password;
};

void InitSecurity();

AuthResult Authenticate(const AuthParams& params);

std::string GetHWID();

std::string GenerateNonce(size_t len = 16);

}