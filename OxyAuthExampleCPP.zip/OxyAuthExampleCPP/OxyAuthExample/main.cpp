﻿#include <iostream>
#include <string>
#include "oxorany_include.h"
#include "OxyAuthLib.h"

int main() {
    OxyAuth::InitSecurity();

    std::cout << oxorany("=================================\n");
    std::cout << oxorany("  OxyAuth Secure License System  \n");
    std::cout << oxorany("=================================\n\n");

    std::cout << oxorany("Choose authentication method:\n[1] Licence\n[2] Username/Password\nChoice: ");
    std::string choiceStr;
    std::getline(std::cin, choiceStr);
    int choice = atoi(choiceStr.c_str());

    OxyAuth::AuthParams params;
    params.appKey = oxorany(""); // change to ur app key

    if (choice == 2) {
        std::cout << oxorany("Enter username: ");
        std::getline(std::cin, params.username);
        std::cout << oxorany("Enter password: ");
        std::getline(std::cin, params.password);
        if (params.username.empty() || params.password.empty()) {
            std::cout << oxorany("[-] Username and password cannot be empty!\n");
            system(oxorany("pause"));
            return 1;
        }
    } else {
        std::cout << oxorany("Enter your license key: ");
        std::getline(std::cin, params.license);
        if (params.license.empty()) {
            std::cout << oxorany("[-] License key cannot be empty!\n");
            system(oxorany("pause"));
            return 1;
        }
    }

    std::cout << oxorany("\n[*] Authenticating with server...\n\n");
    OxyAuth::AuthResult result = OxyAuth::Authenticate(params);

    if (result.success) {
        std::cout << oxorany("====================================") << std::endl;
        std::cout << oxorany("[+] Authentication successful!\n");
        std::cout << oxorany("====================================") << std::endl;
        std::cout << oxorany("Your application will now start...\n");
    } else {
        std::cout << oxorany("====================================\n");
        std::cout << oxorany("[-] AUTHENTICATION FAILED\n");
        std::cout << oxorany("====================================\n");
        std::cout << oxorany("Error: ") << result.errorMessage << std::endl;
        std::cout << oxorany("If you believe this is an error, please contact support.\n");
        system(oxorany("pause"));
        return 1;
    }

    system(oxorany("pause"));
    return 0;
}