import subprocess
import requests
import os

API_URL = "http://oxyluaprrttct.mygamesonline.org/apicheck.php"
APP_KEY = ""  # replace by your actual app key

def get_hwid():
    try:
        output = subprocess.check_output(
            ["wmic", "path", "win32_computersystemproduct", "get", "uuid"],
            shell=True, text=True
        ).splitlines()
        for line in output:
            line = line.strip()
            if line and line != "UUID":
                return line
    except Exception:
        return "UNKNOWN_HWID"
    return "UNKNOWN_HWID"

def get_public_ip():
    try:
        return requests.get("https://api.ipify.org").text.strip()
    except Exception:
        return "UNKNOWN_IP"

def check_license(license_key):
    hwid = get_hwid()
    ip_addr = get_public_ip()

    data = {
        "appkey": APP_KEY.strip(),
        "license": license_key.strip(),
        "hwid": hwid.strip(),
        "ip_addr": ip_addr.strip()
    }

    try:
        resp = requests.post(API_URL, data=data, timeout=10)
        return resp.text
    except Exception as e:
        return f"ERROR: {e}"

if __name__ == "__main__":
    license_key = input("Enter your license key: ").strip()
    result = check_license(license_key)

    if result == "VALID":
        print("\n[+] License valid!")
    else:
        print("\n[-] Auth failed:", result)

    os.system("pause")
