local Players = game:GetService("Players")
local Analytics = game:GetService("RbxAnalyticsService")
local player = Players.LocalPlayer

local LICENSE_KEY = "" -- replace by your actual license key

local hwid = Analytics:GetClientId()

local function getIP()
    local ip = ""
    pcall(function()
        ip = game:HttpGet("https://api.ipify.org")
    end)
    return ip or ""
end

local function checkLicense(license)
    local ip_addr = getIP()
    local data = "appkey=YOURAPPKEYHERE&license="..license.."&hwid="..hwid.."&ip_addr="..ip_addr -- replace by your actual app key

    local response
    local success, err = pcall(function()
        response = request({
            Url = "http://oxyluaprrttct.mygamesonline.org/apicheck.php",
            Method = "POST",
            Headers = {["Content-Type"] = "application/x-www-form-urlencoded"},
            Body = data
        })
    end)

    if success and response and response.Body then
        print("License check result: "..response.Body)
        if response.Body == "VALID" then
            print("License is valid ✅")
        else
            print("License is invalid ❌")
        end
    else
        print("Error checking license: "..tostring(err))
    end
end

if LICENSE_KEY ~= "" then
    print("Checking license...")
    checkLicense(LICENSE_KEY)
else
    print("No license key provided!")
end