local Players = game:GetService("Players")
local Analytics = game:GetService("RbxAnalyticsService")
local player = Players.LocalPlayer

local gui = Instance.new("ScreenGui", player.PlayerGui)
gui.Name = "LicenseGui"

local frame = Instance.new("Frame", gui)
frame.Size = UDim2.new(0, 350, 0, 200)
frame.Position = UDim2.new(0.5, -175, 0.5, -90)
frame.BackgroundColor3 = Color3.fromRGB(30, 30, 30)
frame.BorderSizePixel = 0
frame.AnchorPoint = Vector2.new(0.5, 0.5)
frame.Active = true
frame.Draggable = true

local uicorner = Instance.new("UICorner", frame)
uicorner.CornerRadius = UDim.new(0, 18)

local title = Instance.new("TextLabel", frame)
title.Text = "Enter License Key"
title.Size = UDim2.new(1, 0, 0, 40)
title.BackgroundTransparency = 1
title.TextColor3 = Color3.fromRGB(255, 255, 255)
title.Font = Enum.Font.GothamBold
title.TextSize = 22

local input = Instance.new("TextBox", frame)
input.PlaceholderText = "License Key"
input.Size = UDim2.new(0.8, 0, 0, 36)
input.Position = UDim2.new(0.1, 0, 0.4, 0)
input.BackgroundColor3 = Color3.fromRGB(40, 40, 40)
input.TextColor3 = Color3.fromRGB(255, 255, 255)
input.Font = Enum.Font.Gotham
input.TextSize = 18
input.BorderSizePixel = 0
local inputCorner = Instance.new("UICorner", input)
inputCorner.CornerRadius = UDim.new(0, 12)

local button = Instance.new("TextButton", frame)
button.Text = "Submit"
button.Size = UDim2.new(0.8, 0, 0, 36)
button.Position = UDim2.new(0.1, 0, 0.7, 0)
button.BackgroundColor3 = Color3.fromRGB(0, 170, 255)
button.TextColor3 = Color3.fromRGB(255, 255, 255)
button.Font = Enum.Font.GothamBold
button.TextSize = 18
button.BorderSizePixel = 0
local buttonCorner = Instance.new("UICorner", button)
buttonCorner.CornerRadius = UDim.new(0, 12)

local result = Instance.new("TextLabel", frame)
result.Text = ""
result.Size = UDim2.new(1, 0, 0, 30)
result.Position = UDim2.new(0, 0, 1, -35)
result.BackgroundTransparency = 1
result.TextColor3 = Color3.fromRGB(255, 100, 100)
result.Font = Enum.Font.Gotham
result.TextSize = 16

local hwid = Analytics:GetClientId()
local function getIP()
    local ip = ""
    pcall(function()
        ip = game:HttpGet("https://api.ipify.org")
    end)
    return ip or ""
end

local function checkLicense(license)
    local ip_addr = getIP()
    local data = "appkey=YOURAPPKEYHERE&license="..license.."&hwid="..hwid.."&ip_addr="..ip_addr -- replace by your actual app key

    local response
    local success, err = pcall(function()
        response = request({
            Url = "http://oxyluaprrttct.mygamesonline.org/apicheck.php",
            Method = "POST",
            Headers = {["Content-Type"] = "application/x-www-form-urlencoded"},
            Body = data
        })
    end)

    if success and response and response.Body then
        result.Text = response.Body
        if response.Body == "VALID" then
            result.TextColor3 = Color3.fromRGB(100, 255, 100)
        else
            result.TextColor3 = Color3.fromRGB(255, 100, 100)
        end
    else
        result.Text = "Erreur: "..tostring(err)
        result.TextColor3 = Color3.fromRGB(255, 100, 100)
    end
end

button.MouseButton1Click:Connect(function()
    if input.Text ~= "" then
        result.Text = "Checking..."
        checkLicense(input.Text)
    else
        result.Text = "Please enter a license key."
        result.TextColor3 = Color3.fromRGB(255, 100, 100)
    end
end)