﻿using OxyAuthSystem;
using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.DataFormats;

namespace OxyAuthExample
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private async void guna2Button1_ClickAsync(object sender, EventArgs e)
        {
            string licenseKey = licensekey.Text.Trim();

            if (string.IsNullOrEmpty(licenseKey))
            {
                MessageBox.Show("Please enter a license key!", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            guna2Button1.Enabled = false;
            guna2Button1.Text = "Authenticating...";
            licensekey.Enabled = false;

            try
            {
                var result = await OxyAuthSystem.OxyAuth.AuthenticateAsync(licenseKey);

                if (result.Success)
                {
                    MessageBox.Show(
                        "✓ Authentication successful!\n\n" +
                        "Response signature verified\n" +
                        "Anti-replay protection: ACTIVE\n" +
                        "Anti-tamper protection: ACTIVE\n\n" +
                        "Your application will now start...",
                        "Success",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Information
                    );
                    // application logic here when logged in
                    
                }
                else
                {
                    string title = "Authentication Failed";
                    string message = result.Message;

                    if (result.IsTampered)
                    {
                        title = "⚠ SECURITY WARNING";
                        message = "🛡️ CRITICAL SECURITY ALERT!\n\n" + message + "\n\n" +
                                 "Possible causes:\n" +
                                 "• tampering detected\n" +
                                 "• Network traffic is being modified\n" +
                                 "• Man-in-the-middle attack\n\n" +
                                 "Please close all debugging tools and try again.";
                    }
                    else if (result.IsReplayAttack)
                    {
                        title = "⚠ REPLAY ATTACK DETECTED";
                        message = "🛡️ SECURITY ALERT!\n\n" + message + "\n\n" +
                                 "Someone attempted to replay a captured response.\n" +
                                 "This attack has been blocked.";
                    }

                    MessageBox.Show(message, title, MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred:\n{ex.Message}", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                guna2Button1.Enabled = true;
                guna2Button1.Text = "Login";
                licensekey.Enabled = true;
            }
        }
    }
}
