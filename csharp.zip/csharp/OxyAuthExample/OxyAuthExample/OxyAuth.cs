﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Management;
using System.Net.Http;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace OxyAuthSystem
{
    public class OxyAuth
    {
        private const string HMAC_SECRET = "0c51fb8dde8c7e944b36d179b41ccfd792ea524bf014badfb9103b98ceb263e1"; // don't change !
        private const string SERVER_HOST = "sxtpa.shop";
        private const string SERVER_PATH = "/apicheck.php";
        private const string APP_KEY = ""; // change your app key here
        private const bool USE_HTTPS = false;

        private static string _requestLicense = "";
        private static string _requestHWID = "";
        private static string _responseData = "";

        public class AuthResult
        {
            public bool Success { get; set; }
            public string Message { get; set; }
            public string ErrorCode { get; set; }
            public bool IsReplayAttack { get; set; }
            public bool IsTampered { get; set; }
        }
        private static bool IsHTTPDebuggerRunning()
        {
            try
            {
                var processes = Process.GetProcesses();
                return processes.Any(p =>
                    p.ProcessName.Equals("HTTPDebuggerSvc", StringComparison.OrdinalIgnoreCase) ||
                    p.ProcessName.Equals("HTTPDebuggerUI", StringComparison.OrdinalIgnoreCase) ||
                    p.ProcessName.Equals("Fiddler", StringComparison.OrdinalIgnoreCase) ||
                    p.ProcessName.Equals("Charles", StringComparison.OrdinalIgnoreCase));
            }
            catch
            {
                return false;
            }
        }

        private static string GetHWID()
        {
            try
            {
                string uuid = "";
                using (var searcher = new ManagementObjectSearcher("SELECT UUID FROM Win32_ComputerSystemProduct"))
                {
                    foreach (ManagementObject obj in searcher.Get())
                    {
                        uuid = obj["UUID"]?.ToString() ?? "";
                        break;
                    }
                }

                return string.IsNullOrEmpty(uuid) ? "UNKNOWN_HWID" : uuid;
            }
            catch
            {
                return "UNKNOWN_HWID";
            }
        }

        private static string SHA256Hash(string input)
        {
            using (var sha256 = SHA256.Create())
            {
                byte[] bytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(input));
                return BitConverter.ToString(bytes).Replace("-", "").ToLower();
            }
        }

        private static string HMACSHA256(string key, string data)
        {
            using (var hmac = new HMACSHA256(Encoding.UTF8.GetBytes(key)))
            {
                byte[] hash = hmac.ComputeHash(Encoding.UTF8.GetBytes(data));
                return BitConverter.ToString(hash).Replace("-", "").ToLower();
            }
        }

        private static string UrlEncode(string value)
        {
            return Uri.EscapeDataString(value);
        }

        private static bool VerifyServerResponse(string response)
        {
            try
            {
                var parts = response.Split('|');
                if (parts.Length != 3) return false;

                string status = parts[0];
                string encodedData = parts[1];
                string signature = parts[2];

                if (status != "VALID") return false;

                byte[] decodedBytes = Convert.FromBase64String(encodedData);
                string jsonData = Encoding.UTF8.GetString(decodedBytes);
                _responseData = jsonData;

                string expectedSignature = HMACSHA256(HMAC_SECRET, jsonData);
                if (!expectedSignature.Equals(signature, StringComparison.OrdinalIgnoreCase))
                {
                    return false;
                }

                var jsonDoc = JsonDocument.Parse(jsonData);
                if (jsonDoc.RootElement.TryGetProperty("timestamp", out var timestampElement))
                {
                    long serverTime = timestampElement.GetInt64();
                    long currentTime = DateTimeOffset.UtcNow.ToUnixTimeSeconds();
                    if (Math.Abs(currentTime - serverTime) > 30)
                    {
                        return false;
                    }
                }

                return true;
            }
            catch
            {
                return false;
            }
        }

        public static async Task<AuthResult> AuthenticateAsync(string licenseKey)
        {
            var result = new AuthResult { Success = false };

            try
            {
                if (IsHTTPDebuggerRunning())
                {
                    result.Message = "HTTP Debugger detected! Please close all debugging tools.";
                    result.ErrorCode = "DEBUGGER_DETECTED";
                    result.IsTampered = true;
                    return result;
                }

                if (string.IsNullOrWhiteSpace(licenseKey))
                {
                    result.Message = "License key cannot be empty";
                    result.ErrorCode = "EMPTY_LICENSE";
                    return result;
                }

                string hwid = GetHWID();
                if (hwid == "UNKNOWN_HWID")
                {
                    result.Message = "Could not generate hardware ID";
                    result.ErrorCode = "HWID_ERROR";
                    return result;
                }

                _requestLicense = licenseKey;
                _requestHWID = hwid;

                string timestamp = DateTimeOffset.UtcNow.ToUnixTimeSeconds().ToString();

                var requestParams = new SortedDictionary<string, string>
                {
                    { "appkey", APP_KEY },
                    { "hwid", hwid },
                    { "license", licenseKey },
                    { "timestamp", timestamp }
                };

                var hmacData = string.Join("&", requestParams.Select(kvp => $"{kvp.Key}={UrlEncode(kvp.Value)}"));
                string signature = HMACSHA256(HMAC_SECRET, hmacData);

                var postData = new Dictionary<string, string>
                {
                    { "appkey", APP_KEY },
                    { "license", licenseKey },
                    { "hwid", hwid },
                    { "timestamp", timestamp },
                    { "signature", signature }
                };

                using (var client = new HttpClient())
                {
                    client.Timeout = TimeSpan.FromSeconds(10);
                    string url = $"{(USE_HTTPS ? "https" : "http")}://{SERVER_HOST}{SERVER_PATH}";

                    var content = new FormUrlEncodedContent(postData);
                    var response = await client.PostAsync(url, content);
                    string responseText = await response.Content.ReadAsStringAsync();

                    if (!responseText.Contains("|"))
                    {
                        if (responseText == "VALID" || responseText.StartsWith("VALID"))
                        {
                            result.Message = "HTTP Debugger tampering detected! Response was modified.";
                            result.ErrorCode = "TAMPERED_RESPONSE";
                            result.IsTampered = true;
                            return result;
                        }

                        result.Message = GetErrorMessage(responseText);
                        result.ErrorCode = responseText;
                        return result;
                    }

                    if (!VerifyServerResponse(responseText))
                    {
                        result.Message = "Response signature verification failed! Possible tampering detected.";
                        result.ErrorCode = "SIGNATURE_MISMATCH";
                        result.IsTampered = true;
                        return result;
                    }

                    if (!_responseData.Contains($"\"{_requestLicense}\"") || !_responseData.Contains($"\"{_requestHWID}\""))
                    {
                        result.Message = "Replay attack detected! Response does not match request.";
                        result.ErrorCode = "REPLAY_ATTACK";
                        result.IsReplayAttack = true;
                        return result;
                    }

                    result.Success = true;
                    result.Message = "Authentication successful!";
                    result.ErrorCode = "VALID";
                    return result;
                }
            }
            catch (HttpRequestException ex)
            {
                result.Message = $"Network error: {ex.Message}";
                result.ErrorCode = "NETWORK_ERROR";
                return result;
            }
            catch (Exception ex)
            {
                result.Message = $"Unexpected error: {ex.Message}";
                result.ErrorCode = "UNKNOWN_ERROR";
                return result;
            }
        }

        private static string GetErrorMessage(string code)
        {
            var errors = new Dictionary<string, string>
            {
                { "VALID", "Authentication successful!" },
                { "INVALID_REQUEST", "Malformed request or IP not detected" },
                { "ACCESS_DENIED", "Your IP address is blacklisted" },
                { "TOO_MANY_ATTEMPTS", "Too many failed attempts. Please try again later" },
                { "MISSING_PARAMS", "Required parameters missing" },
                { "INVALID_FORMAT", "Invalid input format" },
                { "INVALID_TIMESTAMP", "Request timestamp invalid or expired" },
                { "INVALID_SIGNATURE", "Security signature verification failed" },
                { "RATE_LIMIT_EXCEEDED", "Too many requests. Please wait and try again" },
                { "INVALID_APP", "Application key not recognized" },
                { "INVALID_LICENSE", "License key is invalid" },
                { "LICENSE_BANNED", "This license has been banned" },
                { "EXPIRED", "License has expired" },
                { "HWID_MISMATCH", "Hardware ID mismatch. License bound to another device" },
                { "SYSTEM_ERROR", "Server error. Please contact support" },
                { "TAMPERED_RESPONSE", "Server response has been tampered with!" }
            };

            return errors.TryGetValue(code, out string message) ? message : $"Unknown error: {code}";
        }
    }
}
