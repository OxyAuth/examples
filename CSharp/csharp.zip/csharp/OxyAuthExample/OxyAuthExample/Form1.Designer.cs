﻿using Guna.UI2.WinForms.Suite;
using System.Resources;

namespace OxyAuthExample
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            CustomizableEdges customizableEdges3 = new CustomizableEdges();
            CustomizableEdges customizableEdges4 = new CustomizableEdges();
            CustomizableEdges customizableEdges1 = new CustomizableEdges();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            CustomizableEdges customizableEdges2 = new CustomizableEdges();
            guna2BorderlessForm1 = new Guna.UI2.WinForms.Guna2BorderlessForm(components);
            guna2Button1 = new Guna.UI2.WinForms.Guna2Button();
            label1 = new Label();
            license = new Guna.UI2.WinForms.Guna2TextBox();
            label2 = new Label();
            SuspendLayout();
            // 
            // guna2BorderlessForm1
            // 
            guna2BorderlessForm1.BorderRadius = 20;
            guna2BorderlessForm1.ContainerControl = this;
            guna2BorderlessForm1.DockIndicatorTransparencyValue = 0.6D;
            guna2BorderlessForm1.ShadowColor = Color.FromArgb(128, 255, 255);
            guna2BorderlessForm1.TransparentWhileDrag = true;
            // 
            // guna2Button1
            // 
            guna2Button1.Animated = true;
            guna2Button1.BorderRadius = 10;
            guna2Button1.CustomizableEdges = customizableEdges3;
            guna2Button1.DisabledState.BorderColor = Color.DarkGray;
            guna2Button1.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2Button1.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2Button1.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2Button1.FillColor = Color.FromArgb(22, 22, 24);
            guna2Button1.Font = new Font("Segoe UI", 9F);
            guna2Button1.ForeColor = Color.FromArgb(96, 103, 150);
            guna2Button1.Location = new Point(50, 150);
            guna2Button1.Name = "guna2Button1";
            guna2Button1.ShadowDecoration.CustomizableEdges = customizableEdges4;
            guna2Button1.Size = new Size(180, 45);
            guna2Button1.TabIndex = 6;
            guna2Button1.Text = "Login";
            guna2Button1.Click += guna2Button1_ClickAsync;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.White;
            label1.Location = new Point(0, 41);
            label1.Name = "label1";
            label1.Size = new Size(280, 25);
            label1.TabIndex = 1;
            label1.Text = "Welcome to OxyAuth Example";
            // 
            // license
            // 
            license.AutoRoundedCorners = true;
            license.BackColor = Color.FromArgb(20, 19, 22);
            license.BorderColor = Color.Yellow;
            license.BorderRadius = 18;
            license.Cursor = Cursors.IBeam;
            license.CustomizableEdges = customizableEdges1;
            license.DefaultText = "";
            license.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            license.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            license.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            license.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            license.FillColor = Color.FromArgb(22, 22, 24);
            license.FocusedState.BorderColor = Color.Transparent;
            license.Font = new Font("Segoe UI", 9F);
            license.ForeColor = Color.White;
            license.HoverState.BorderColor = Color.Transparent;
            license.IconRight = (Image)resources.GetObject("license.IconRight");
            license.Location = new Point(22, 88);
            license.Name = "license";
            license.PlaceholderForeColor = Color.FromArgb(51, 50, 58);
            license.PlaceholderText = "License key";
            license.SelectedText = "";
            license.ShadowDecoration.CustomizableEdges = customizableEdges2;
            license.Size = new Size(233, 39);
            license.TabIndex = 3;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.White;
            label2.Location = new Point(12, 130);
            label2.Name = "label2";
            label2.Size = new Size(0, 20);
            label2.TabIndex = 7;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(20, 19, 22);
            ClientSize = new Size(281, 207);
            Controls.Add(label2);
            Controls.Add(license);
            Controls.Add(label1);
            Controls.Add(guna2Button1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Guna.UI2.WinForms.Guna2BorderlessForm guna2BorderlessForm1;
        private Guna.UI2.WinForms.Guna2Button guna2Button1;
        private Label label1;
        private Guna.UI2.WinForms.Guna2TextBox license;
        private Label label2;
    }
}