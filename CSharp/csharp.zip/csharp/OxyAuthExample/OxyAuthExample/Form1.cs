﻿using OxyAuth;
using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.DataFormats;

namespace OxyAuthExample
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private async void guna2Button1_ClickAsync(object sender, EventArgs e)
        {
            string licenseKey = license.Text.Trim();

            string result = await Auth.CheckLicenseAsync(licenseKey);
            if (result == "VALID")
            {
                // successful login
                MessageBox.Show("Login successful!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                // login failed
                label2.Text = "Login failed: " + result;
            }
        }
    }
}
