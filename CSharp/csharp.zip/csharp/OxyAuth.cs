using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Net.Http;
using System.Threading.Tasks;

namespace OxyAuth
{
    public static class Auth
    {
        private static readonly string AppKey = ""; // Replace with your actual app key

        public static async Task<string> CheckLicenseAsync(string license)
        {
            string hwid = GetHWID();
            string publicIp = await GetPublicIPAsync();
            using (var client = new HttpClient())
            {
                var data = new FormUrlEncodedContent(new[]
                {
                    new KeyValuePair<string, string>("appkey", AppKey),
                    new KeyValuePair<string, string>("license", license),
                    new KeyValuePair<string, string>("hwid", hwid),
                    new KeyValuePair<string, string>("ip_addr", publicIp)
                });

                var resp = await client.PostAsync("http://oxyluaprrttct.mygamesonline.org/apicheck.php", data);
                return await resp.Content.ReadAsStringAsync();
            }
        }

        public static async Task<string> GetPublicIPAsync()
        {
            using (var client = new HttpClient())
            {
                return await client.GetStringAsync("https://api.ipify.org");
            }
        }

        public static string GetHWID()
        {
            try
            {
                var process = new Process
                {
                    StartInfo = new ProcessStartInfo
                    {
                        FileName = "wmic",
                        Arguments = "path win32_computersystemproduct get uuid",
                        RedirectStandardOutput = true,
                        UseShellExecute = false,
                        CreateNoWindow = true
                    }
                };
                process.Start();
                string output = process.StandardOutput.ReadToEnd();
                process.WaitForExit();

                var lines = output.Split(new[] { '\n', '\r' }, StringSplitOptions.RemoveEmptyEntries);
                if (lines.Length >= 2)
                    return lines[1].Trim();
                return "UNKNOWN_HWID";
            }
            catch
            {
                return "UNKNOWN_HWID";
            }
        }
    }
}